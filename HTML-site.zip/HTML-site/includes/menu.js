// JavaScript Document


if (document.images) 
	{
		PlusImg = new Image
		MinusImg = new Image
		PlusImg.src = '../images/plus.gif'
		MinusImg.src = '../images/minus.gif'
	}
	else
	{
		PlusImg = ""
		MinusImg = ""
		document.arrow = ""
	}
	

bShowContent1 = false;

function showHideContent(id, imageID)
	{
		var elem = document.getElementById(id);
		
		if (elem) 
			{
				if (elem.style.visibility != 'hidden') 
					{	//hides area
						document.cookie = id + "=hidden"
						elem.style.display = 'none';
						elem.style.visibility = 'hidden';
						imageName = PlusImg.src;
					}
				else
					{           //shows area
						document.cookie = id + "=open"
						elem.style.display = 'block';
						elem.style.visibility = 'visible';
						imageName = MinusImg.src;
					} 
				document.arrow[imageID].src = imageName;
			}
	}     
		
		 
function showSubContent(id, imageID)
	{
		var elem = document.getElementById(id);
		
		if (elem) 
			{
				if (elem.style.visibility != 'hidden') 
					{	//hides area
						elem.style.display = 'none';
						elem.style.visibility = 'hidden';
						imageName = PlusImg.src;
					}
				else
					{	//shows area
						elem.style.display = 'block';
						elem.style.visibility = 'visible';
						imageName = MinusImg.src;
					} 
			document.arrowSub[imageID].src = imageName;
			}
	}  
	 
function showSub2Content(id, imageID)
	{
		var elem = document.getElementById(id);
		
		if (elem) 
		{
			if (elem.style.visibility != 'hidden') 
					{	//hides area
						elem.style.display = 'none';
						elem.style.visibility = 'hidden';
						imageName = PlusImg.src;
					}
				else
					{	//shows area
						elem.style.display = 'block';
						elem.style.visibility = 'visible';
						imageName = MinusImg.src;
					}
				
			document.arrowSub_1[imageID].src = imageName;
		}  //end if elem
	} 
	
	
function showSub3Content(id, imageID)
	{
		var elem = document.getElementById(id);
			if (elem) 
			{
				if (elem.style.visibility != 'hidden') 
					{	//hides area
						elem.style.display = 'none';
						elem.style.visibility = 'hidden';
						imageName = PlusImg.src;
					}
				else
					{	//shows area
						elem.style.display = 'block';
						elem.style.visibility = 'visible';
						imageName = MinusImg.src;
					} 
			
		document.arrowSub_2[imageID].src = imageName;
		}
	}