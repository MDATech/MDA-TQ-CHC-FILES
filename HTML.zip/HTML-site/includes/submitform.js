// JavaScript Document

<!--
function submitIT(form)
{
if (form.txtSubject.value == "")
{
	alert("You must enter a patient's name");
	form.txtSubject.focus();
	return false;
}
//if (form.Date_of_Birth.value == "")
//	{
//	alert("You must enter a date of birth");
//	form.Date_of_Birth.focus();
//	return false;
//	}
return true;
}
-->