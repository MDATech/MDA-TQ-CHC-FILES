// JavaScript Document
<!--
function chkequip(formItem)
{
	if (formItem.value == "")
	{
		alert("You must enter equipment name.");
		formItem.focus();
		return false;
	}
return true;
}
-->