// JavaScript Document
<!--

var sssecs
var sstimerID = null
var sstimerRunning = false
var ssdelay = 1000
var ssoReq = false

    // Mozilla/Safari
    if (window.XMLHttpRequest) { 
		ssoReq = new XMLHttpRequest(); 
		}
    // IE
    else if (window.ActiveXObject) { 
		ssoReq = new ActiveXObject("Microsoft.XMLHTTP");
		}

function ssInitializeTimer()
{
    // Set the length of the timer, in seconds
    sssecs = 5
	updateSysStats()
    ssStopTheClock()
    ssStartTheTimer()
}

function ssStopTheClock()
{
    if(sstimerRunning)
        clearTimeout(sstimerID)
    sstimerRunning = false
}

function ssStartTheTimer()
{
    if (sssecs==0)
    {
        ssStopTheClock()
        // Update all 4 panels
		
		
		ssInitializeTimer()
    }
    else
    {
		//self.status=sssecs
        sssecs = sssecs - 1
        sstimerRunning = true
        sstimerID = self.setTimeout("ssStartTheTimer()", ssdelay)
    }
}


function updateSysStats() {
	var urlLoc = "desktop/panels/systemstats.asp"
	//for installations under/on intranets, it may be necessary to monkey with the initial value of i in the loop
	for (i = 0;i<document.location.pathname.split("/").length-2;i++)
	{
			urlLoc = "../" + urlLoc
	}
	//document.write(document.location.pathname)
	//document.write(urlLoc)
	//alert(urlLoc);
	ssoReq.open('POST', urlLoc, false);
	
    ssoReq.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    ssoReq.onreadystatechange = function() 
		{
        if (ssoReq.readyState == 4) { 
			var arrStats = ssoReq.responseText.split(",");	
			document.getElementById("IncompleteTransports").innerHTML = arrStats[0];
			document.getElementById("TransportersOnDuty").innerHTML = arrStats[1];
			document.getElementById("ETA").innerHTML = arrStats[2];
			document.getElementById("CurrentDateTime").innerHTML = Date();
			}
		}
    ssoReq.send();
}




-->