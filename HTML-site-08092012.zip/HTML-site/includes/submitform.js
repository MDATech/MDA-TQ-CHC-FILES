// JavaScript Document

<!--
function submitIT(form)
{
if (form.txtSubject.value == "")
{
	alert("You must enter a patient's name");
	form.txtSubject.focus();
	return false;
}

if (form.MRN.value == "" && form.Date_of_Birth.value == "")
{
alert("You must enter a Medical Record Number or Date of Birth");
form.MRN.focus();
return false;
}

if (form.txtOrigin.value == "")
{
alert("You must select an Origin.");
form.txtOrigin.focus();
return false;
}

if (form.txtDest.value == "")
{
alert("You must select a destination.");
form.txtDest.focus();
return false;
}

return true;
}
-->